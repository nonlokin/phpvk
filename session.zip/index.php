<?php 
$con = mysqli_connect('127.0.0.1', 'root', '', '???');
$query = mysqli_query($con, "SELECT * FROM users WHERE name='Люба' AND password='123'");
$stroka = $query->fetch_assoc();
$num = mysqli_num_rows($query);
if($num>0){
	//header("Location: posts.php");
} else{
	//echo "Нет такого пользователя";
}
?>
