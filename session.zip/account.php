<h1>Личный кабинет</h1>
<?php 
$con = mysqli_connect('127.0.0.1', 'root', '', '???');
$query = mysqli_query($con, "SELECT * FROM users WHERE id=???");
$stroka = $query->fetch_assoc();
echo "Привет, " . $stroka["name"];
?>
<a href="posts.php">Назад</a>